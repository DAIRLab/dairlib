Begin Control -- optimal control problem

   Discretization                  HS
*  Discretization                  TR
   Control Solution               Yes
   Refinement                     Yes
   System information             Yes

   Superbasics limit             2000

   Major iterations              1000
   Major Print level            00001
   Minor print level                1

   Solution                       Yes
End   Control
