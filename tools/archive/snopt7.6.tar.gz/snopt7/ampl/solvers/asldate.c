long ASLdate_ASL = 20161228;
