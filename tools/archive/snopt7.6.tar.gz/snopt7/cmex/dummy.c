/* dummy.c - Exists only to help "mex" recognize this as a cmex package */

