%cmex directory
addpath([pwd,'/..'],'-end');
%cute directory
addpath([getenv('HOME'), '/iotr-cute/mex' ], '-end');
