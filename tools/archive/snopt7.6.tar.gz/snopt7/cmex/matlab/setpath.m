function setpath(varargin)

addpath([pwd,'/examples'       ], '-end');
addpath([pwd,'/examples/t1diet'], '-end');
addpath([pwd,'/examples/sntoy' ], '-end');
addpath([pwd,'/examples/snmain'], '-end');
addpath([pwd,'/examples/hsmain'], '-end');
