#include "f2c.h"

int MAIN__ (void) { return 0; }

