char F2C_version[] = "20100827";
char xxxvers[] = "\n@(#) FORTRAN 77 to C Translator, VERSION 20100827\n";
