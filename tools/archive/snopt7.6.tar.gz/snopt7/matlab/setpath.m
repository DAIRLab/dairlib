function setpath(varargin)

addpath([pwd,'/examples'       ], '-end');
addpath([pwd,'/examples/t1diet'], '-end');
addpath([pwd,'/examples/sntoy' ], '-end');
addpath([pwd,'/examples/snmain'], '-end');
addpath([pwd,'/examples/hsmain'], '-end');
addpath([pwd,'/examples/hs76'  ], '-end');
addpath([pwd,'/examples/fmincon'], '-end');
addpath([pwd,'/examples/hs116'  ], '-end');
addpath([pwd,'/examples/spring' ], '-end');

