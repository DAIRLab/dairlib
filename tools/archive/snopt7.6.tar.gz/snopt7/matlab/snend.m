% function snend
%   Deallocate memory.
%

function snend

endOpt = 999;
snoptmex ( endOpt );