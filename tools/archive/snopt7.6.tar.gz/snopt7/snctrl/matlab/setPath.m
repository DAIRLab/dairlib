function setpath

addpath([pwd],'-end');
addpath([pwd,'/../mex/'],'-end');
addpath([pwd,'/examples'],'-end');
addpath([pwd,'/examples/Breakwell'],'-end');
addpath([pwd,'/examples/brachistochrone'],'-end');
addpath([pwd,'/examples/catmix'],'-end');
addpath([pwd,'/examples/diplant'],'-end');
addpath([pwd,'/examples/pendulum'],'-end');
addpath([pwd,'/examples/vanderpol'],'-end');
addpath([pwd,'/examples/vtbrachistochrone'],'-end');


